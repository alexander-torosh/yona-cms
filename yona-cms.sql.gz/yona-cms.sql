-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 14, 2014 at 05:48 PM
-- Server version: 5.5.35
-- PHP Version: 5.4.6-1ubuntu1.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yona-cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE IF NOT EXISTS `admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`id`, `login`, `email`, `password`, `active`) VALUES
(1, 'admin', 'web@wezoom.net', '$2y$10$IgvGXdrkaRpuXnQLcpva3ebuRdNqbcY7NvlS9aluVQIgHWLf1bIMa', 1),
(2, 'yona', 'yona@wezoom.net', '$2y$10$2UUYmTf4f13el.b5K69WmeijY6E/nY4.hRYaokNe/lfyfvJ3Bz05O', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_configuration`
--

CREATE TABLE IF NOT EXISTS `cms_configuration` (
  `key` varchar(50) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cms_configuration`
--

INSERT INTO `cms_configuration` (`key`, `value`) VALUES
('DEBUG_MODE', '1'),
('TECHNICAL_WORKS', '0');

-- --------------------------------------------------------

--
-- Table structure for table `cms_javascript`
--

CREATE TABLE IF NOT EXISTS `cms_javascript` (
  `id` varchar(20) NOT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cms_javascript`
--

INSERT INTO `cms_javascript` (`id`, `text`) VALUES
('body', '<!-- custom javascript code or any html -->'),
('head', '<!-- custom javascript code or any html -->');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iso` varchar(10) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `url` varchar(20) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  `primary` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `iso`, `name`, `url`, `sortorder`, `primary`) VALUES
(1, 'ru', 'Русский', '', 1, '1'),
(2, 'en', 'English', 'en', 2, '0'),
(3, 'uk', 'Українська', 'uk', 3, '0');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE IF NOT EXISTS `page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'index', '2014-08-03 15:18:47', '2014-10-14 17:43:17'),
(2, 'contacts', '2014-08-03 22:25:13', '2014-10-14 17:40:45');

-- --------------------------------------------------------

--
-- Table structure for table `page_translate`
--

CREATE TABLE IF NOT EXISTS `page_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(20) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `foreign_id` (`foreign_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `page_translate`
--

INSERT INTO `page_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'title', 'Главная'),
(2, 1, 'ru', 'meta_title', 'Главная'),
(3, 1, 'ru', 'meta_description', 'meta-описание главной страницы'),
(4, 1, 'ru', 'meta_keywords', ''),
(5, 1, 'ru', 'text', '<h1>Стартовая страница</h1>\r\n<p>Каждый сайт, разработанный нашей веб-студией, является уникальным продуктом. <strong>Мы не используем</strong> бесплатные CMS-системы такие как Joomla, Wordpress, 1С-битрикс&nbsp;и т.п.</p>\r\n<p>Наша веб-студия, создавая сайты, применяет технологии PHP,&nbsp;<br /><strong>Phalcon</strong>, MySQL, MongoDb, Memcached, Redis, JavaScript, AngularJs, KnockoutJs, современную адаптивную HTML5 верстку и др.</p>\r\n<h2>Подзаголовок</h2>\r\n<p>С радостью беремся за интересные и нестандартные проекты.</p>\r\n<p>Применение технологий, которые мы используем, позволяет нам создавать сайты стандарта Web 2.0. Наши продукты отличаются своей гибкостью, что дает широкие возможности при модернизации сайта в любой момент его создания или поддержки.</p>\r\n<h3>Под-подзаголовок</h3>\r\n<p>В процессе создания сайта мы оптимизируем его под будущее продвижение в поисковых системах. Это имеет значительное влияние на качество и скорость индексации сайта поисковиками (Google, Яндекс, Yahoo) и<strong> экономит Ваш бюджет</strong> при продвижении сайта.</p>\r\n<p>Наша веб-студия использует свой самописный движок, который имеет:</p>\r\n<ul>\r\n<li>Высокую безопасность, надежность, быстродействие и легко масштабируется</li>\r\n<li>Функциональную и удобную панель администрирования сайта\r\n<ul>\r\n<li>Вложенный уровень</li>\r\n<li>Еще один</li>\r\n</ul>\r\n</li>\r\n<li>Нормальный уровень</li>\r\n</ul>\r\n<p>Таблица</p>\r\n<table class="table" style="width: 100%;">\r\n<tbody>\r\n<tr><th>Заглавие</th><th>Заглавие</th><th>Заглавие</th></tr>\r\n<tr>\r\n<td>Текст в ячейке</td>\r\n<td>Текст в ячейке</td>\r\n<td>Текст в ячейке</td>\r\n</tr>\r\n<tr>\r\n<td>Текст в ячейке</td>\r\n<td>Текст в ячейке</td>\r\n<td>Текст в ячейке</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>Числовой список:</p>\r\n<ol>\r\n<li>Первый</li>\r\n<li>Второй</li>\r\n<li>Третий</li>\r\n</ol>'),
(6, 1, 'en', 'title', 'Homepage'),
(7, 1, 'en', 'meta_title', 'Homepage'),
(8, 1, 'en', 'meta_description', ''),
(9, 1, 'en', 'meta_keywords', ''),
(10, 1, 'en', 'text', '<p>Homepage text</p>'),
(11, 2, 'ru', 'title', 'Контакты'),
(12, 2, 'ru', 'meta_title', NULL),
(13, 2, 'ru', 'meta_description', ''),
(14, 2, 'ru', 'meta_keywords', ''),
(15, 2, 'ru', 'text', '<p>web@wezoom.net</p>'),
(16, 2, 'en', 'title', 'Contacts'),
(17, 2, 'en', 'meta_title', 'Contacts'),
(18, 2, 'en', 'meta_description', ''),
(19, 2, 'en', 'meta_keywords', ''),
(20, 2, 'en', 'text', '<p>web@wezoom.net</p>'),
(21, 1, 'uk', 'title', 'Головна'),
(22, 1, 'uk', 'meta_title', 'Головна'),
(23, 1, 'uk', 'meta_description', ''),
(24, 1, 'uk', 'meta_keywords', ''),
(25, 1, 'uk', 'text', '<p>Текст головної сторінки</p>'),
(26, 2, 'uk', 'title', 'Контакти'),
(27, 2, 'uk', 'meta_title', 'Контакти'),
(28, 2, 'uk', 'meta_description', ''),
(29, 2, 'uk', 'meta_keywords', ''),
(30, 2, 'uk', 'text', '');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE IF NOT EXISTS `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `visible` enum('1','0') NOT NULL DEFAULT '1',
  `sortorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `project_image`
--

CREATE TABLE IF NOT EXISTS `project_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `publication`
--

CREATE TABLE IF NOT EXISTS `publication` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL DEFAULT 'events',
  `slug` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `preview_inner` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `publication`
--

INSERT INTO `publication` (`id`, `type`, `slug`, `created_at`, `updated_at`, `date`, `preview_inner`) VALUES
(1, 'news', 'phalcon-132-released', '2014-08-22 10:33:26', '2014-10-14 17:47:28', '2014-08-22 00:00:00', '0'),
(2, 'news', 'phalcon-community-hangout', '2014-08-22 10:42:08', '2014-10-14 17:47:49', '2014-08-21 00:00:00', '0');

-- --------------------------------------------------------

--
-- Table structure for table `publication_translate`
--

CREATE TABLE IF NOT EXISTS `publication_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(20) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `foreign_id` (`foreign_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `publication_translate`
--

INSERT INTO `publication_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'title', 'Phalcon 1.3.2 Released'),
(2, 1, 'ru', 'meta_title', 'Phalcon 1.3.2 Released'),
(3, 1, 'ru', 'meta_description', ''),
(4, 1, 'ru', 'meta_keywords', ''),
(5, 1, 'ru', 'text', '<p>We are today releasing the much awaited 1.3.2 version.&nbsp;</p>\r\n<p>This version has a ton of contributions from our community and fixes to the framework. We thank everyone that has worked on this release, especially with their contributions both to 1.3.2 and our work in progress 2.0.0.</p>\r\n<p>Many thanks to dreamsxin, <a href="https://github.com/mruz">mruz</a>, <a href="https://github.com/kjdev">kjdev</a>, <a href="https://github.com/Cinderella-Man">Cinderella-Man</a>, <a href="https://github.com/andreadelfino">andreadelfino</a>, <a href="https://github.com/kfll">kfll</a>, <a href="https://github.com/brandonlamb">brandonlamb</a>, <a href="https://github.com/zacek">zacek</a>, <a href="https://github.com/joni">joni</a>, <a href="https://github.com/wandersonwhcr">wandersonwhcr</a>, <a href="https://github.com/kevinhatry">kevinhatry</a>, <a href="https://github.com/alkana">alkana</a> and many others that have contributed either on <a href="https://github.com/phalcon/cphalcon">Github or through discussion in our </a><a href="http://forum.phalconphp.com/">forum</a>.</p>\r\n<p>The changelog can be found <a href="https://github.com/phalcon/cphalcon/blob/master/CHANGELOG">here</a>.</p>\r\n<p>We also have a number of pull requests that have not made it to 1.3.2 but will be included to 1.3.3. We need to make sure that the fix or feature that each pull request offers are present both in 1.3.3 but also in 2.0.0</p>\r\n<p>A big thank you once again to our community! You guys are awesome!</p>\r\n<p>&lt;3 Phalcon Team</p>'),
(6, 2, 'ru', 'title', 'Phalcon Community Hangout'),
(7, 2, 'ru', 'meta_title', 'Phalcon Community Hangout'),
(8, 2, 'ru', 'meta_description', ''),
(9, 2, 'ru', 'meta_keywords', ''),
(10, 2, 'ru', 'text', '<p>Yesterday (2014-04-05) we had our first Phalcon community hangout. The main purpose of the hangout was to meet the community, discuss about what Phalcon is and what our future steps are, and hear news, concerns, success stories from the community itself.</p>\r\n<p>We are excited to announce that the first Phalcon community hangout was a great success!</p>\r\n<p>We had an awesome turnout from all around the world, with members of the community filling the hangout (10 concurrent users) and more viewing online, asking questions and interacting with the team.</p>\r\n<p>We talked about where we are, where we came from and what the future steps are with Zephir and Phalcon 2.0. Contributions, bugs and NFRs were also topics in our discussion, as well as who are team and how Phalcon is funded.</p>\r\n<p>More hangouts will be scheduled in the near future, hopefully making this a regular event for our community. We will also cater for members of the community that are not English speakers, by creating hangouts for Spanish speaking, Russian etc. The goal is to engage as many members as possible!</p>\r\n<p>The love and trust you all have shown to our framework is what drives us to make it better, push performance, introduce more features and make Phalcon the best PHP framework there is.&nbsp;</p>\r\n<p>For those that missed it, the video is below.</p>'),
(11, 1, 'en', 'title', 'Phalcon 1.3.2 Released'),
(12, 1, 'en', 'meta_title', 'Phalcon 1.3.2 Released'),
(13, 1, 'en', 'meta_description', ''),
(14, 1, 'en', 'meta_keywords', ''),
(15, 1, 'en', 'text', '<p>We are today releasing the much awaited 1.3.2 version.&nbsp;</p>\r\n<p>This version has a ton of contributions from our community and fixes to the framework. We thank everyone that has worked on this release, especially with their contributions both to 1.3.2 and our work in progress 2.0.0.</p>\r\n<p>Many thanks to dreamsxin, <a href="https://github.com/mruz">mruz</a>, <a href="https://github.com/kjdev">kjdev</a>, <a href="https://github.com/Cinderella-Man">Cinderella-Man</a>, <a href="https://github.com/andreadelfino">andreadelfino</a>, <a href="https://github.com/kfll">kfll</a>, <a href="https://github.com/brandonlamb">brandonlamb</a>, <a href="https://github.com/zacek">zacek</a>, <a href="https://github.com/joni">joni</a>, <a href="https://github.com/wandersonwhcr">wandersonwhcr</a>, <a href="https://github.com/kevinhatry">kevinhatry</a>, <a href="https://github.com/alkana">alkana</a> and many others that have contributed either on <a href="https://github.com/phalcon/cphalcon">Github or through discussion in our </a><a href="http://forum.phalconphp.com/">forum</a>.</p>\r\n<p>The changelog can be found <a href="https://github.com/phalcon/cphalcon/blob/master/CHANGELOG">here</a>.</p>\r\n<p>We also have a number of pull requests that have not made it to 1.3.2 but will be included to 1.3.3. We need to make sure that the fix or feature that each pull request offers are present both in 1.3.3 but also in 2.0.0</p>\r\n<p>A big thank you once again to our community! You guys are awesome!</p>\r\n<p>&lt;3 Phalcon Team</p>'),
(16, 1, 'uk', 'title', 'Phalcon 1.3.2 Released'),
(17, 1, 'uk', 'meta_title', 'Phalcon 1.3.2 Released'),
(18, 1, 'uk', 'meta_description', ''),
(19, 1, 'uk', 'meta_keywords', ''),
(20, 1, 'uk', 'text', '<p>We are today releasing the much awaited 1.3.2 version.&nbsp;</p>\r\n<p>This version has a ton of contributions from our community and fixes to the framework. We thank everyone that has worked on this release, especially with their contributions both to 1.3.2 and our work in progress 2.0.0.</p>\r\n<p>Many thanks to dreamsxin, <a href="https://github.com/mruz">mruz</a>, <a href="https://github.com/kjdev">kjdev</a>, <a href="https://github.com/Cinderella-Man">Cinderella-Man</a>, <a href="https://github.com/andreadelfino">andreadelfino</a>, <a href="https://github.com/kfll">kfll</a>, <a href="https://github.com/brandonlamb">brandonlamb</a>, <a href="https://github.com/zacek">zacek</a>, <a href="https://github.com/joni">joni</a>, <a href="https://github.com/wandersonwhcr">wandersonwhcr</a>, <a href="https://github.com/kevinhatry">kevinhatry</a>, <a href="https://github.com/alkana">alkana</a> and many others that have contributed either on <a href="https://github.com/phalcon/cphalcon">Github or through discussion in our </a><a href="http://forum.phalconphp.com/">forum</a>.</p>\r\n<p>The changelog can be found <a href="https://github.com/phalcon/cphalcon/blob/master/CHANGELOG">here</a>.</p>\r\n<p>We also have a number of pull requests that have not made it to 1.3.2 but will be included to 1.3.3. We need to make sure that the fix or feature that each pull request offers are present both in 1.3.3 but also in 2.0.0</p>\r\n<p>A big thank you once again to our community! You guys are awesome!</p>\r\n<p>&lt;3 Phalcon Team</p>'),
(21, 2, 'en', 'title', 'Phalcon Community Hangout'),
(22, 2, 'en', 'meta_title', 'Phalcon Community Hangout'),
(23, 2, 'en', 'meta_description', ''),
(24, 2, 'en', 'meta_keywords', ''),
(25, 2, 'en', 'text', '<p>Yesterday (2014-04-05) we had our first Phalcon community hangout. The main purpose of the hangout was to meet the community, discuss about what Phalcon is and what our future steps are, and hear news, concerns, success stories from the community itself.</p>\r\n<p>We are excited to announce that the first Phalcon community hangout was a great success!</p>\r\n<p>We had an awesome turnout from all around the world, with members of the community filling the hangout (10 concurrent users) and more viewing online, asking questions and interacting with the team.</p>\r\n<p>We talked about where we are, where we came from and what the future steps are with Zephir and Phalcon 2.0. Contributions, bugs and NFRs were also topics in our discussion, as well as who are team and how Phalcon is funded.</p>\r\n<p>More hangouts will be scheduled in the near future, hopefully making this a regular event for our community. We will also cater for members of the community that are not English speakers, by creating hangouts for Spanish speaking, Russian etc. The goal is to engage as many members as possible!</p>\r\n<p>The love and trust you all have shown to our framework is what drives us to make it better, push performance, introduce more features and make Phalcon the best PHP framework there is.&nbsp;</p>\r\n<p>For those that missed it, the video is below.</p>'),
(26, 2, 'uk', 'title', 'Phalcon Community Hangout'),
(27, 2, 'uk', 'meta_title', 'Phalcon Community Hangout'),
(28, 2, 'uk', 'meta_description', ''),
(29, 2, 'uk', 'meta_keywords', ''),
(30, 2, 'uk', 'text', '<p>Yesterday (2014-04-05) we had our first Phalcon community hangout. The main purpose of the hangout was to meet the community, discuss about what Phalcon is and what our future steps are, and hear news, concerns, success stories from the community itself.</p>\r\n<p>We are excited to announce that the first Phalcon community hangout was a great success!</p>\r\n<p>We had an awesome turnout from all around the world, with members of the community filling the hangout (10 concurrent users) and more viewing online, asking questions and interacting with the team.</p>\r\n<p>We talked about where we are, where we came from and what the future steps are with Zephir and Phalcon 2.0. Contributions, bugs and NFRs were also topics in our discussion, as well as who are team and how Phalcon is funded.</p>\r\n<p>More hangouts will be scheduled in the near future, hopefully making this a regular event for our community. We will also cater for members of the community that are not English speakers, by creating hangouts for Spanish speaking, Russian etc. The goal is to engage as many members as possible!</p>\r\n<p>The love and trust you all have shown to our framework is what drives us to make it better, push performance, introduce more features and make Phalcon the best PHP framework there is.&nbsp;</p>\r\n<p>For those that missed it, the video is below.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `seo_manager`
--

CREATE TABLE IF NOT EXISTS `seo_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `custom_name` varchar(50) DEFAULT NULL,
  `route` varchar(50) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `controller` varchar(50) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  `route_params_json` text,
  `query_params_json` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `seo_manager`
--

INSERT INTO `seo_manager` (`id`, `custom_name`, `route`, `module`, `controller`, `action`, `language`, `route_params_json`, `query_params_json`, `created_at`, `updated_at`) VALUES
(1, 'Новости', 'publications', NULL, '', '', 'ru', '{"type" : "news"}', '', '2014-09-30 10:39:23', '2014-10-01 18:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `seo_manager_translate`
--

CREATE TABLE IF NOT EXISTS `seo_manager_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(20) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `foreign_id` (`foreign_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `seo_manager_translate`
--

INSERT INTO `seo_manager_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'head_title', 'Последние новости'),
(2, 1, 'ru', 'meta_description', 'Раздел сайта с последними новостями'),
(3, 1, 'ru', 'meta_keywords', ''),
(4, 1, 'ru', 'seo_text', 'Самые свежие и интересные новости. SEO-текст для тестирования');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `animation_speed` varchar(255) DEFAULT NULL,
  `delay` varchar(255) DEFAULT NULL,
  `visible` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `title`, `animation_speed`, `delay`, `visible`) VALUES
(1, 'Слайдер на главной странице', '300', '5', '1');

-- --------------------------------------------------------

--
-- Table structure for table `slider_image`
--

CREATE TABLE IF NOT EXISTS `slider_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slider_id` int(11) NOT NULL,
  `sortorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slider_id` (`slider_id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `slider_image`
--

INSERT INTO `slider_image` (`id`, `slider_id`, `sortorder`) VALUES
(1, 1, 1),
(2, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `slider_translate`
--

CREATE TABLE IF NOT EXISTS `slider_translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreign_id` int(11) NOT NULL,
  `lang` varchar(20) DEFAULT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `foreign_id` (`foreign_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `slider_translate`
--

INSERT INTO `slider_translate` (`id`, `foreign_id`, `lang`, `key`, `value`) VALUES
(1, 1, 'ru', 'caption', ''),
(2, 1, 'ru', 'link', ''),
(3, 2, 'ru', 'caption', ''),
(4, 2, 'ru', 'link', '');

-- --------------------------------------------------------

--
-- Table structure for table `translate`
--

CREATE TABLE IF NOT EXISTS `translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(20) DEFAULT NULL,
  `phrase` varchar(500) DEFAULT NULL,
  `translation` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `translate`
--

INSERT INTO `translate` (`id`, `lang`, `phrase`, `translation`) VALUES
(1, 'ru', 'Подробнее', 'Подробнее'),
(2, 'en', 'Подробнее', 'Read more'),
(3, 'ru', 'Администраторы', 'Администраторы'),
(4, 'ru', 'Добавить', 'Добавить'),
(5, 'ru', 'Добавить Administrator', 'Добавить Administrator'),
(6, 'ru', 'Сохранить', 'Сохранить'),
(7, 'ru', 'Редактировать администратора', 'Редактировать администратора'),
(8, 'ru', 'Удалить администратора', 'Удалить администратора'),
(9, 'ru', 'Административная панель YonaCms', 'Административная панель YonaCms'),
(10, 'ru', 'Стартовая страница', 'Стартовая страница'),
(11, 'ru', 'Login is required', 'Login is required'),
(12, 'ru', 'Password is required', 'Password is required'),
(13, 'ru', 'Login', 'Login'),
(14, 'ru', 'Email format required', 'Email format required'),
(15, 'ru', 'Email is required', 'Email is required'),
(16, 'ru', 'Password', 'Password'),
(17, 'ru', 'Active', 'Active'),
(18, 'ru', 'Form validation fails', 'Form validation fails'),
(19, 'ru', 'Назад', 'Назад'),
(20, 'ru', 'Подтвердить удаление', 'Подтвердить удаление'),
(21, 'ru', 'Редактировать публикацию', 'Редактировать публикацию'),
(22, 'ru', 'Add', 'Add'),
(23, 'ru', 'Edit', 'Edit'),
(24, 'ru', 'Email', 'Email'),
(25, 'ru', 'Back', 'Back'),
(26, 'ru', 'Delete', 'Delete'),
(27, 'en', 'Администраторы', 'Администраторы'),
(28, 'en', 'Добавить', 'Добавить'),
(29, 'en', 'Добавить Administrator', 'Добавить Administrator'),
(30, 'en', 'Сохранить', 'Сохранить'),
(31, 'en', 'Редактировать администратора', 'Редактировать администратора'),
(32, 'en', 'Удалить администратора', 'Удалить администратора'),
(33, 'en', 'Административная панель YonaCms', 'Административная панель YonaCms'),
(34, 'en', 'Стартовая страница', 'Стартовая страница'),
(35, 'en', 'Login is required', 'Login is required'),
(36, 'en', 'Password is required', 'Password is required'),
(37, 'en', 'Login', 'Login'),
(38, 'en', 'Email format required', 'Email format required'),
(39, 'en', 'Email is required', 'Email is required'),
(40, 'en', 'Password', 'Password'),
(41, 'en', 'Active', 'Active'),
(42, 'en', 'Form validation fails', 'Form validation fails'),
(43, 'en', 'Назад', 'Back'),
(44, 'en', 'Подтвердить удаление', 'Подтвердить удаление'),
(45, 'en', 'Редактировать публикацию', ''),
(46, 'en', 'Add', 'Add'),
(47, 'en', 'Edit', 'Edit'),
(48, 'en', 'Email', 'Email'),
(49, 'en', 'Back', 'Back'),
(50, 'en', 'Delete', 'Delete'),
(51, 'ru', 'SITE NAME', 'Yona CMS'),
(52, 'ru', 'Главная', 'Главная'),
(53, 'ru', 'Новости', 'Новости'),
(54, 'ru', 'Контакты', 'Контакты'),
(55, 'en', 'SITE NAME', 'Yona CMS'),
(56, 'en', 'Главная', 'Home'),
(57, 'en', 'Новости', 'News'),
(58, 'en', 'Контакты', 'Contacts'),
(59, 'uk', 'SITE NAME', 'Yona CMS'),
(60, 'uk', 'Главная', 'Головна'),
(61, 'uk', 'Новости', 'Новини'),
(62, 'uk', 'Контакты', 'Контакти'),
(63, 'uk', 'Назад', 'Назад'),
(64, 'uk', 'Подтвердить удаление', ''),
(65, 'uk', 'Администраторы', ''),
(66, 'uk', 'Добавить', ''),
(67, 'uk', 'Добавить Administrator', ''),
(68, 'uk', 'Сохранить', ''),
(69, 'uk', 'Редактировать администратора', ''),
(70, 'uk', 'Удалить администратора', ''),
(71, 'uk', 'Административная панель YonaCms', ''),
(72, 'uk', 'Стартовая страница', ''),
(73, 'uk', 'Login is required', ''),
(74, 'uk', 'Password is required', ''),
(75, 'uk', 'Login', ''),
(76, 'uk', 'Email format required', ''),
(77, 'uk', 'Email is required', ''),
(78, 'uk', 'Password', ''),
(79, 'uk', 'Active', ''),
(80, 'uk', 'Подробнее', 'Детальніше'),
(81, 'uk', 'Form validation fails', 'Помилка валідації форми');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `youtube_link` varchar(255) DEFAULT NULL,
  `sortorder` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `widget`
--

CREATE TABLE IF NOT EXISTS `widget` (
  `id` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `html` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `page_translate`
--
ALTER TABLE `page_translate`
  ADD CONSTRAINT `page_translate_ibfk_1` FOREIGN KEY (`foreign_id`) REFERENCES `page` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_image`
--
ALTER TABLE `project_image`
  ADD CONSTRAINT `project_image_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `publication_translate`
--
ALTER TABLE `publication_translate`
  ADD CONSTRAINT `publication_translate_ibfk_1` FOREIGN KEY (`foreign_id`) REFERENCES `publication` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `seo_manager_translate`
--
ALTER TABLE `seo_manager_translate`
  ADD CONSTRAINT `seo_manager_translate_ibfk_1` FOREIGN KEY (`foreign_id`) REFERENCES `seo_manager` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `slider_image`
--
ALTER TABLE `slider_image`
  ADD CONSTRAINT `slider_image_ibfk_2` FOREIGN KEY (`slider_id`) REFERENCES `slider` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `slider_translate`
--
ALTER TABLE `slider_translate`
  ADD CONSTRAINT `slider_translate_ibfk_1` FOREIGN KEY (`foreign_id`) REFERENCES `slider_image` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
